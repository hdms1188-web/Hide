# Cloudflare Pages版 RTAランキング

RTAは「ワールド生成完了」から「エンダードラゴン討伐後、帰還ゲートへ入る」までを計測します。難易度ノーマル、チート無効、死亡時の持ち物保持なしで固定されます。途中セーブから再開した走行は参考記録となり、端末内には残りますが世界ランキングへは送信されません。

ホーム画面には最速記録を表示します。Cloudflareへ接続できる公開版では「RTA 世界記録」、HTML単体やAPI未接続時は「RTA この端末の最速」と表示されます。

## Cloudflare Pagesへの設定

1. ZIPを展開し、そのフォルダーでCloudflareへログインします。
   - `npx wrangler login`
2. D1データベースを作成します。
   - `npx wrangler d1 create blockopia-rta`
3. テーブルを作成します。
   - `npx wrangler d1 execute blockopia-rta --remote --file=./migrations/0001_rta_records.sql`
4. Pagesへ一度デプロイします。
   - `npx wrangler pages deploy . --project-name=blockopia`
5. Cloudflareダッシュボードで、対象Pagesプロジェクトの `Settings > Bindings > Add > D1 database bindings` を開きます。変数名を必ず `RTA_DB` とし、`blockopia-rta` を選択します。
6. 同じデプロイコマンドをもう一度実行します。バインドは再デプロイ後に有効になります。

Git連携でも利用できます。ビルドコマンドは空欄、出力ディレクトリは `.`、D1の変数名は `RTA_DB` にしてください。Functionsを有効にするため、静的ファイルだけのドラッグ＆ドロップではなく、WranglerまたはGit連携で公開してください。

ランキングAPIは同梱の `functions/api/rta-ranking.js` にあり、URLは `/api/rta-ranking` です。D1が未設定・通信不能の場合、ゲームは自動的に端末内ランキングへ切り替わります。
